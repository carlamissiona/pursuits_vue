<template>

     <div class="container">              
        <div class="container">
            <div class="row">
                <div class="col-md-1">
                    <section id="intro" style="position:relative;z-index:200;margin:0 14px;">
                   
                       <div class="col-md-1">
                           <left-side-menu :menu="sidelinks"></left-side-menu> 
                       </div>
                    </section>
                  </div>
                <div class="col-md-11 col-md-offset-1">
                     <div id="main">
                      <!-- Post -->
                        <div class="row">
                            <div class="col-md-12">
                                <article class="post">
                                    <header>
                                        <div class="title" style="padding-left:75px;">
                                            <h2><a href="#">Careers</a></h2>
                                            <p>Jobs. Your Pursuits. Find Your bacon.
                                             <br>
                                            </p>
                                        </div>
                                        <div class="meta text-center">
                                           <h3><a href="jobs-applied.html">Applications</a></h3>
                                           <h3><a href="assessments.html">Assessments</a></h3>
                                           <h3><a href="interviews.html">Interviews</a></h3>
                                        </div>
                                    </header>
                                    <div>
                                    </div>
                                    <header>
                                        <br>
                                        <div class="col-md-12 col-md-offset-1">
                                             <br> <br>
                                            <span class="form-group col-md-10">
                                               <input type="text" class="form-control active" placeholder="Jobs Near You">
                                           </span>
                                            <br>
                                           <span class="form-group col-md-10">
                                            <div class="select-wrapper">
                                                    <select name="demo-category" id="demo-category">
                                                        <option value="">- Category -</option>
                                                        <option value="1">Manufacturing</option>
                                                        <option value="1">Shipping</option>
                                                        <option value="1">Administration</option>
                                                        <option value="1">Human Resources</option>
                                                    </select>
                                                </div>
                                       </span>
                                            <br>
                                             <span class="form-group col-md-10">
                                            <div class="select-wrapper">
                                                    <select name="demo-category" id="demo-category">
                                                        <option value="">- Employement Type -</option>
                                                        <option value="1">Part-time</option>
                                                        <option value="1">Full-Time</option>
                                                        <option value="1">Internship</option>
                                                        <option value="1">Contractual</option>
                                                    </select>
                                                </div>
                                           </span>
                                            <br>


                                            <span class="form-group col-md-6">
                                           <input type="submit" class="btn small btn-primary" value="Search Jobs">
                                         <br> <br>
                                                </span>
                                             <br>
                                        </div>
                                        <br>
                                        <br>
                                        <div class="meta">
                                                <h3>Job Ads</h3>
                                                <h3>Job Ads</h3>
                                        </div>

                                         <br> <br> <br>
                                    </header>

                                    <header class="text-center" style="float:none;clear:both;">
                                        <br>
                                        <hr>
                                        <div class="forum-question">
                                            <br>
                                            <br>
                                            <h3>Search Result</h3>
                                            <br>
                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo1" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo1" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            <br>


                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo2" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo2" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo1" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo1" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            
                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo1" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo1" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            
                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo1" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo1" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            
                                            <div class=" col-md-9 col-md-offset-1 text-center">

                                                <h4 class="12u text-justify"> <a href="#demo1" data-toggle="collapse" aria-expanded="true"> Frontend Developer </a> </h4>

                                                <div id="demo1" class="collapse in text-justify">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-1"><br><i class="fa fa-bullseye fa-lg" aria-hidden="true"></i></div>
                                            
                                            

                                        </div>
                                        

                                    </header>
                                    <footer>
                                        <ul class="actions">
                                            <li><a href="guild-home.html" class="button big">WATCH ONE NOW</a></li>
                                        </ul>
                                        <ul class="promo" style="width:60%; float:right;">
                                            <h3> Get 40% Discount on All Courses</h3>
                                        </ul>
                                        <hr>

                                    </footer>
                                </article>
                                <!---------- Notifications -------->

                                <!-------------- FORUMS -------------->
                            </div>
                        </div>
                  
                    </div>
                </div>
        </div>
        </div>
              
  </div>

</template>

<script>
 import LeftSideMenu from './LeftSideMenu.vue';
 import feeds from '../assets/objects/feeds.json';
 import axios from 'axios';

export default {
  name: 'Careers',
  data  () {
     return {
         sidelinks: [
          {
            href: 'about.html',
            icon: 'fa fa-search'
          }
            ,
          {
            href: 'home.html',
            icon: 'fa fa-search'
           },
             {
            href: 'logout.html',
            icon: 'fa fa-search'
           }
         ]

     }
        
    }
  ,
  components : { LeftSideMenu },
  created() {
   
  },


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
