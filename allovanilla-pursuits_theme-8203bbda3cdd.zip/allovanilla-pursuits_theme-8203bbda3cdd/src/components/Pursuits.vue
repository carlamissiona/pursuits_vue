<template>

     <div class="container">              
        <div class="container">
            <div class="row">
                <div class="col-md-1">
                    <section id="intro" style="position:relative;z-index:200;margin:0 14px;">
                   
                       <div class="col-md-1">
                           <left-side-menu :menu="sidelinks"></left-side-menu> 
                       </div>
                    </section>
                  </div>
                <div class="col-md-11 col-md-offset-1">
                     <div id="main">
                        <div class="row">
                             <div class="col-md-12">
                                <article class="post" style="padding:0 auto 20px auto;">
                                   <header>
                                      <div class="title">
                                          <h2><a href="#">Pursuits</a></h2>
                                            <p>This is is my daily grind. I work and work for my family for living.<br>
                                           </p>
                                      </div>
                                      <div class="meta">
                                         <span class="fh5co-icon"><i class="icon-trophy"></i>443</span>
                                         <strong class="fh5co-uppercase-sm">Guild Rank</strong>
                                         <br>
                                         <span class="fh5co-icon"><i class="icon-rocket"></i>80%</span>
                                         <strong class="fh5co-uppercase-sm">Hireability<br>Score </strong>
                                         <br>
                                         <strong><a href="#notifs">See Notifications</a></strong>
                                      </div>
                                   </header>                           
                                       
                                    <div class="row" style="margin-bottom:30px;"> 
                                         <div class="col-md-2 col-md-offset-1">
                                             <router-link :to="{ path: 'open-store'}"><i class="fa fa-shopping-basket fa-2x circle-icon" style="color:gray;padding:15px; " aria-hidden="true"></i><br>Open a Store</router-link>
                                             <br>   
                                         </div>
                                         <div class="col-md-2">
                                             <router-link :to="{ path: 'open-project'}"><i class="fa fa-rocket fa-2x circle-icon" style="color:gray;padding:15px;" aria-hidden="true"></i><br>Build a Product</router-link>
                                             <br>   
                                         </div>
                                         <div class="col-md-2">
                                            <router-link :to="{ path: 'open-service'}"><i class="fa fa-cogs fa-2x circle-icon" style="color:gray;padding:15px; " aria-hidden="true"></i><br>Create a Service</router-link>
                                             <br>    
                                         </div> 
                                          <div class="col-md-2">
                                             <router-link :to="{ path: 'careers'}"><i class="fa fa-briefcase fa-2x circle-icon" style="color:gray;padding:15px; " aria-hidden="true"></i><br>Find a Job</router-link> 
                                             <br>    
                                         </div> 
                                                                        
                                    </div>
                           

                                     
                                </article>
                            
                          
                                <!---------- Notifications -------->
                                <!---------- Notifications -------->
                                <article class="post" id="notifs">
                                   <header>
                                      <div class="title">
                                         <h3>My Pursuits</h3>
                                      </div>
                                      <div class="meta">
                                         <a href="#" class="author text-center">
                                         <span class="text-right">You have 4<br>Orders @Store</span>&nbsp;&nbsp;
                                         <img src="images/avatar.jpg" alt="">
                                         </a>
                                      </div>
                                  
                                   </header>
                                   <!--------Pursuits ---------->
                                   <footer>
                                      <div style="display:block;height:contain; margin:30px 10px; padding:20px 0px; ">
                                         <div class="col-md-4 text-center">
                                            <a href="project-dashboard.html"><img src="http://lorempixel.com/130/130/abstract/1/" class="text-center img-circle"> </a><br><br>
                                            <h3><strong>Sleep Rythmn Mobile App</strong></h3>
                                            <p class="text-justify"> 
                                               Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat.  
                                            </p>
                                         </div>
                                         <div class="col-md-4 text-center">
                                            <a href="store-dashboard.html"><img src="http://lorempixel.com/130/130/abstract/1/" class="text-center img-circle"></a> <br><br>
                                            <h3><strong>Empanada Republic</strong></h3>
                                            <p class="text-justify"> 
                                               Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat.  
                                            </p>
                                         </div>
                                         <div class="col-md-4 text-center">
                                            <a href="jobs-applied.html"> <img src="http://lorempixel.com/130/130/abstract/1/" class=" text-center img-circle"> </a><br><br>
                                            <h3><strong>3 Job Applications</strong></h3>
                                            <p class="text-justify">
                                               Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat.    
                                            </p>
                                         </div>
                                         <hr>
                                      </div>
                                   </footer>
                                   <footer>
                                   </footer>
                                </article>
                                <!---------- Notifications -------->
                                <!---------- Notifications -------->
                                <!------------   Feeds ------------>
                                <!------------   Feeds ------------>
                                <article class="post">
                                   <header>
                                      <div class="title">
                                         <h3>Discover Pursuits</h3>
                                      </div>
                                      
                                   </header>
                                    
                                   <br>
                                   <footer>
                                       
                                   </footer>
                                   <br>
                                </article>
                             </div>
                        </div>
                    </div>
                </div>
        </div>
        </div>
              
  </div>

</template>

<script>
 import LeftSideMenu from './LeftSideMenu.vue';
 import feeds from '../assets/objects/feeds.json';
 import axios from 'axios';

export default {
  name: 'Pursuits',
  data  () {
     return {
         sidelinks: [
          {
            href: 'about.html',
            icon: 'fa fa-search'
          }
            ,
          {
            href: 'home.html',
            icon: 'fa fa-search'
           },
             {
            href: 'logout.html',
            icon: 'fa fa-search'
           }
         ]

     }
        
    }
  ,
  components : { LeftSideMenu },
  created() {
   
  },


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
