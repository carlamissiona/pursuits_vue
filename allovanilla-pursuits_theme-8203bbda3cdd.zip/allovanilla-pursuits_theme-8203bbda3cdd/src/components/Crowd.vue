<template>

     <div class="container">              
        <div class="container">
            <div class="row">
                <div class="col-md-1">
                    <section id="intro" style="position:relative;z-index:200;margin:0 14px;">
                   
                       <div class="col-md-1">
                           <left-side-menu :menu="sidelinks"></left-side-menu> 
                       </div>
                    </section>
                  </div>
                <div class="col-md-11 col-md-offset-1">
                     <div id="main">
                       <div class="row">
                        <div class="col-md-12">
                           <article class="post">
                              <header style="height:178px;">
                                 <div class="title" style="padding-left:75px;">
                                    <h2><a href="#">Crowd</a></h2>
                                    <p>Fun &amp; Hustling, Enterprising Crowd.<br><br><br>
                                    </p>
                                 </div>
                                
                                 <div class="meta">
                                    <br>
                                      <a href="store.html" class="button small"> Your Connections</a><br><br>
                                 </div>
                              </header>
                             
                               <header>
                                          <div class="12u">
                                             <img src="http://lorempixel.com/64/60/sports/1/" style="float:left;">
                                             <img src="http://lorempixel.com/65/60/food/1/" style="float:left;">
                                             <img src="http://lorempixel.com/64/60/sports/1/" style="float:left;">
                                             <img src="http://lorempixel.com/65/60/food/1/" style="float:left;">
                                             <img src="http://lorempixel.com/62/60/sports/1/" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/food/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/61/60/abstract/1/" style="float:left;">
                                             <img src="http://lorempixel.com/66/60/people/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/city/1/" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/transport/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/nature/1/" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/cats/1/" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/sports/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/transport/1/" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/fashion/1/" style="float:left;"><img src="http://lorempixel.com/60/60/fashion/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/60/60/people/1/" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/city/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/65/60/cats/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/65/60/sports/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/cats/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/sports/1/" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/people/1/" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/city/1/" style="float:left;">
                                             <img src="http://lorempixel.com/65/60/business/1/" style="float:left;">
                                             <img src="https://api.adorable.io/avatars/60/abott@adorable.png" style="float:left;">
                                             <img src="http://lorempixel.com/63/60/sports/1/" style="float:left;"><img src="http://lorempixel.com/55/60/sports/1/" style="float:left;">
                                              
                                          </div>
                                                            
                                    </header>
                           </article>
                                 <!---------- Notifications -------->
                                 <!---------- Selling -------->
                           <article class="post" id="notifs">
                                    <header>
                                       <div class="title">
                                          <div class="col-md-12 12u$ ">
                                             <div class="col-md-8 col-sm-12 8u">
                                                <input type="text" style="width:400px; margin:0 10px 0 0;" name="demo-email" value="" placeholder="Find Interesting People">
                                             </div>
                                             <div class="col-md-4 col-sm-12 4u">
                                                <a href="crowd.html" style="margin:0 0 0 25px;" class="button md">Search</a>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="meta text-center" style="float:none;text-align:center;">
                                          <a href="store.html" class="button small">Your Connections</a>
                                       </div>
                                    </header>
                                    <div style="display:block;height:contain; margin:30px 10px; padding:20px 0px; ">
                                       <div class="row">
                                          <div class="form-group row"> 
                                          </div>
                                          <div class="col-md-12">
                                             <br>
                                             <h3 class="text-center">People You Have Same Interest With</h3>
                                             <br>
                                          </div>
                                          <div class="col-md-12">
                                             <br> 
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Charlea Theron</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Max Harley</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Max Harley</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Max Harley</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Max Harley</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                                <br><strong>Maxim Harley</strong> 
                                             </div>
                                             <div class="col-md-2 text-center">
                                                <img src="http://lorempixel.com/60/60/cats/1/" class="text-center img-circle">
                                                <br><strong>Max Harley</strong> 
                                             </div>
                                             <div class="col-md-12">
                                                <br> 
                                                <br> 
                                                <br> 
                                             </div>
                                          </div>
                                          <div class="col-md-12">
                                             <h3 class="text-center">People Who Would like to Pay For Your Work &amp;  Hobbies</h3>
                                             <br>
                                             <br>
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Charlea Theron</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <div class="col-md-2 text-center">
                                             <img src="http://lorempixel.com/60/60/people/1/" class="text-center img-circle"> 
                                             <br><strong>Max Harley</strong> 
                                          </div>
                                          <br><br>
                                       </div>
                                       <div class="row">
                                          <div class="col-md-12 12u">
                                             <br>
                                             <br>
                                             <br>
                                             <h3 class="text-center">People Who Would Like to Mentor You</h3>
                                             <br>
                                             <br>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                          </div>
                                       </div>
                                       <br>
                                       <div class="row">
                                          <div class="col-md-12 12u ">
                                             <br>
                                             <br>
                                             <h3 class="text-center">Services &amp; Stores Near You</h3>
                                             <br>
                                             <br>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                             <div class="col-md-4">
                                                <article class="mini-post">
                                                   <header>
                                                      <h3><a href="#">Vitae sed condimentum Guild</a></h3>
                                                      <small>33 Guild Members</small><br><a href="#"><small>Join</small></a>
                                                      <a href="#" class="author"><img src="images/avatar.jpg" alt=""></a>
                                                   </header>
                                                   <a href="#" class="image"><img src="images/pic04.jpg" alt=""></a>
                                                </article>
                                             </div>
                                          </div>
                                       </div>
                                       <footer>
                                          <br>
                                          <br>
                                          <br>
                                          <br> 
                                       </footer>
                                       </div>
                           </article>
                        </div>
                  </div>
                    </div>
                </div>
        </div>
        </div>
              
  </div>

</template>

<script>
 import LeftSideMenu from './LeftSideMenu.vue';
 import feeds from '../assets/objects/feeds.json';
 import axios from 'axios';

export default {
  name: 'Crowd',
  data  () {
     return {
         sidelinks: [
          {
            href: 'about.html',
            icon: 'fa fa-search'
          }
            ,
          {
            href: 'home.html',
            icon: 'fa fa-search'
           },
             {
            href: 'logout.html',
            icon: 'fa fa-search'
           }
         ]

     }
        
    }
  ,
  components : { LeftSideMenu },
  created() {
   
  },


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
