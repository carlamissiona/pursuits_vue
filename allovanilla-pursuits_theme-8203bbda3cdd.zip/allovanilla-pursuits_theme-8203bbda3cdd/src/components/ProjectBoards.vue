<template>

     <div class="container">              
        <div class="container">
            <div class="row">
                <div class="col-md-1">
                    <section id="intro" style="position:relative;z-index:200;margin:0 14px;">
                   
                       <div class="col-md-1">
                           <left-side-menu :menu="sidelinks"></left-side-menu> 
                       </div>
                    </section>
                  </div>
                <div class="col-md-11 col-md-offset-1">
                     <div id="main">
                         <div class="row">
                        <div class="col-md-12 col-md-offset-">
                         <article class="post">
                        <header>
                          <div class="title" style="padding-left:75px;">
                            <h2><a href="#">Sleep Rhythm Mobile App</a></h2>
                            <p>Match your sleep pattern with your natural circadian rhythm. 
                            </p>
                          </div>
                          <div class="meta">
                            <h1>44</h1>
                            
                                         <span class="fh5co-icon"><i class="icon-trophy"></i></span>
                                         <strong class="fh5co-uppercase-sm">Milestones Met</strong>
                             
                              <br>
                                         <strong><a href="#notifs">Edit Project Info</a></strong>
                                         

                                
                          </div>

                        </header>
                        <div>



                        </div>
                      
                      
                     
                  
                 
                    <header>
                      <div class="title" style="padding-left:75px;">
                        <h3>Kanban</h3>
                         
                      </div>               

                    </header>
                    <!-----Drag Kanban----------> 
                    <!-----Drag Kanban----------> 

                    <div class="row">
                      <div class="col-md-4"> <a href="#" class="button small">SET TODO CALENDAR</a><br><br></div>
                      <div class="col-md-12">

                        <div class="col-md-4">
                          <div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                            <h3>TODO</h3>
                            <ul class="todo">
                          <li class="todo-1" style="border:1px thin gray;padding:10px;" draggable="true" ondragstart="drag(event)">
                            Make breakfast

                          </li>
                          <li class="todo-2" style="border:1px thin gray;padding:10px;" draggable="true" ondragstart="drag(event)">
                            Eat breakfast

                          </li>
                          <li class="todo-3" style="border:1px thin gray;padding:10px;" draggable="true" ondragstart="drag(event)">
                            Take out breakfast

                          </li>

                        </ul>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div id="div2" ondrop="drop(event)" ondragover="allowDrop(event)">
                            <h3>DOING</h3>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div id="div3" ondrop="drop(event)" ondragover="allowDrop(event)">
                            <h3>DONE</h3>
                          </div>

                        </div>


                      </div>    

                    </div>
                     
                    <div class="row">
                      <div class="col-md-12">
                        <br><br>
                         
                      </div>
                    </div>
                    
                     
                    <!-----End  Drag Kanban---------->  
                    <footer>
                        
                                    
                    </footer>
                  </article>
                         
                     </div>
                  </div>
                    </div>
                </div>
        </div>
        </div>
              
  </div>

</template>

<script>
 import LeftSideMenu from './LeftSideMenu.vue';
 import feeds from '../assets/objects/feeds.json';
 import axios from 'axios';

export default {
  name: 'Pursuits',
  data  () {
     return {
         sidelinks: [
          {
            href: 'about.html',
            icon: 'fa fa-search'
          }
            ,
          {
            href: 'home.html',
            icon: 'fa fa-search'
           },
             {
            href: 'logout.html',
            icon: 'fa fa-search'
           }
         ]

     }
        
    }
  ,
  components : { LeftSideMenu },
  created() {
   
  },


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
